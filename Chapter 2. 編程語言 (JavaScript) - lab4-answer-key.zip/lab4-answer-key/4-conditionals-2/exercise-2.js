/*
  Conditionals
  ---------------------------------
  Write a function that checks if a student has passed
  - if the grade is less than 50 then return "failed"
  - if 50 or higher then return "passed"

*/

function studentPassed(grade) {
  if (grade > 50) {
    return "passed"
  } else {
    return "failed"
  }
}

/* 
DO NOT EDIT BELOW THIS LINE
--------------------------- */
const grade1 = 49;
const grade2 = 50;
const grade3 = 100;

console.log("'" + grade1 + "': " + studentPassed(grade1))
console.log("'" + grade2 + "': " + studentPassed(grade2))
console.log("'" + grade3 + "': " + studentPassed(grade3))

/* 
Expected Output
---------------
'49': failed
'50': passed
'100': passed
*/
