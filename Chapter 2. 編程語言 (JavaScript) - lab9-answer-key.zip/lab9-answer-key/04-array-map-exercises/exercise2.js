// Task: Capitalize each all the names in the original array
// Tips: You might want to Google on how to capitalize a string

const capitalizeListOfNames = (arr) => {
  // Add your code here
  return arr.map((x) => x.toUpperCase());
};

// DO NOT EDIT CODE BELOW
// Test Cases
console.log(
  capitalizeListOfNames(["peter", "DARREN", "timCook", "sundar pichai"])
);

// Expected Output
// ["PETER", "DARREN", "TIMCOOK", "SUNDAR PICHAI"]
