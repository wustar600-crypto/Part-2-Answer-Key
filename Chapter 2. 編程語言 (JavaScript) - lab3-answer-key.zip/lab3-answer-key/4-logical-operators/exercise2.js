/*
#  Logical Operators
#  ---------------------------------
#  Write a conditional statement that would detect if the input is between 5-10
#  Update the code so that you get the expected result.
*/

number = 7

// Add your code here

if (number >=5 && number <=10){
  console.log("Is 10 in the range 5-10? true")
}
else{
  console.log("Is 10 in the range 5-10? false")
}

// Alternative Solution
console.log("Is 10 in the range 5-10? " + (number >=5 && number <=10))

/* 
*  EXPECTED RESULT
*  ---------------
*  Is 10 in the range 5-10? true
*/
