const prompt = require("prompt-sync")({ sigint: true });

// Random number from 1 - 100
let numberInMind = Math.floor(Math.random() * 100) + 1;

// This variable is used to determine if the app should continue prompting the user for input
let foundCorrectNumber = false;

while (!foundCorrectNumber) {
  // Step 1: Get user input (don't forget that the input is a string)
  let guess = prompt("Guess the number in my mind: ");
  console.log(`Your Guess: ${guess}`);

  // Step 2: Compare the guess to the secret answer and
  // let the user know the feedback (too large, too small, correct).
  if (guess < numberInMind) {
    console.log("It's too small.");
  } else if (guess > numberInMind) {
    console.log("It's too big.");
  } else {
    // guess == numberInMind
    console.log("You're Correct!");

    //Bonus
    foundCorrectNumber = true;
    let willTryAgain = prompt("Try Again?");
    if (willTryAgain === "Y") {
      numberInMind = Math.floor(Math.random() * 100) + 1;
      foundCorrectNumber = false;
    }
  }
}

// Bonus Point: prompt user and provide option for user to start a new game after winning
