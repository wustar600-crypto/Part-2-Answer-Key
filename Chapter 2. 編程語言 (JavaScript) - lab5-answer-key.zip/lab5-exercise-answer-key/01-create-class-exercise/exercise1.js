// Task: Create a Person class.
// This class should have a name attribute, an age attribute.

class Person {  
  constructor(name, age) {  
	 // Task: Fill in the code to initialize the name and age attributes
	 // your code here
	 this.name = name;
	 this.age = age;
  }  
  
}  



// test
const person = new Person("john", 20)
console.log(person.name)
console.log(person.age)

// Expected Output
// john
// 20