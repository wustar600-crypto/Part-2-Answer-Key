// Task: Create an animal class with the following requirements.
// Create a class named Animal.
// This class should have a name attribute and a sound attribute.


class Animal {  

  // Task: Write a constructor that includes the name and sound attributes.
  // your code here
  constructor(name, sound) {  
	 this.name = name;
	 this.sound = sound;
  }  
  
}  

//  test
const dog = new Animal('Buddy', 'Woof!');  
console.log(dog.name)
console.log(dog.sound)

// Expected Output
// Buddy
// Woof!