// Task: Create an animal class with the following requirements.
// Create a class named Animal.
// This class should have a name attribute and a sound attribute.
// Create a method called makeSound(), which returns the animal's call.


class Animal {  

  // Task: Write a constructor that includes the name and sound attributes.
  // your code here
  constructor(name, sound) {  
    this.name = name;  
    this.sound = sound;  
  }  
  
  // Task: Write a  a method called makeSound(), which returns the animal's call.
  // your code here
  makeSound() {  
    return this.sound;  
  }  
}  

// test
const dog = new Animal('Buddy', 'Woof!');  
console.log(dog.name); // Output: Buddy
console.log(dog.makeSound()); // Output: Woof!
  
  
// Expected Output
// Buddy
// Woof!