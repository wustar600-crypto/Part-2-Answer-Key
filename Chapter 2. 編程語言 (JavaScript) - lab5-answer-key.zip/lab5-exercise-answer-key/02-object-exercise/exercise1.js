// Task: Create a Person class.
// This class should have a name attribute, an age attribute, and a greet() method.
// The greet() method should return a string, such as "Hello, my name is [name] and I'm [age] years old.".


class Person {  
  constructor(name, age) {  
	 // Task: Fill in the code to initialize the name and age attributes
	 // your code here
	 this.name = name;
	 this.age = age;
  }  
  
  // Task: the greet() method should return a string, such as "Hello, my name is [name] and I'm [age] years old.".
  // your code here
  greet() {  
		return `Hello, my name is ${this.name} and I'm ${this.age} years old.`;  
  }  
}  
  

// test
// Create a Person object and name it Person, named John, with an age of 20
const person = new Person('John Doe', 30);  
console.log(person.greet()); 


// Expected Output
// Hello, my name is John Doe and I'm 30 years old.