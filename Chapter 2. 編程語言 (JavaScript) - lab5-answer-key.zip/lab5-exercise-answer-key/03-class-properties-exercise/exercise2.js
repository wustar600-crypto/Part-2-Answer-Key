//Task: Define a Person class.
//Private attributes: firstName (string type) and lastName (string type).
// Public attribute: fullName (a getter method that returns a combination of firstName and lastName).


class Person {  
 
    #_firstName;
    #_lastName; 
	
    constructor(firstName, lastName) {  
	
        this.#_firstName = firstName; 
        this.#_lastName = lastName; 
    }  
  
	greet() {  
        console.log("Hello, my name is " + this.fullName);  
    }  


    // Task: Fill in the code to define the fullName getter method，Return the combination of firstName and lastName
	// your code here
    get fullName() {  
        return this.#_firstName + ' ' + this.#_lastName; 
       
    }  
	

    
}  
  
  
// test
const person = new Person('John', 'Doe');  
person.greet(); 


// Expected Output
//Hello, my name is John Doe.






