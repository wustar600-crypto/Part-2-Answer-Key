// Task: Print out the array in reverse order (without using array.reverse())

const arr = [1, 3, 5, 7, 9, 11, 13];

// Add your code here:
let i = arr.length-1
while (i >= 0){
    console.log(arr[i])
    i--
}


// Expected Output: 
// 13
// 11
// 9
// 7
// 5
// 3
// 1
