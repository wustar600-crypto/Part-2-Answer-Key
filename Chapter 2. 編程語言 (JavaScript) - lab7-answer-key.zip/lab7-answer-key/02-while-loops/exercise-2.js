// Task: Print out all positive odd numbers up to n1

const n1 = 19; 

// Add your code here:
let i = 1
while (i <= n1){
    console.log(i)
    i = i + 2
}


// Expected Output:  
// 1
// 3
// 5
// 7
// 9
// 11
// 13
// 15
// 17
// 19