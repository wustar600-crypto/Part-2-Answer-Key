// Task: Print out the sum of the arrays on each index

const array1 = [1, 3, 5];
const array2 = [2, 4, 6];

// Add your code here:
let result = []
for(let i = 0; i<array1.length; i++){
    result[i] = array1[i] + array2[i]
}

console.log(result)

// Expected Output: 
// [3, 7, 11]

