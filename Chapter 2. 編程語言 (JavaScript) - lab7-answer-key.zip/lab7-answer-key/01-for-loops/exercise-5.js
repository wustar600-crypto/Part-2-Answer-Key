// Task: Calculate the factorial of the input
// Tips: factorial of 5 = 5*4*3*2*1

const input = 10

// Add your code here
let result = 1
for (let i = 1; i<=input; i++){
    result *= i
}

console.log(result)

// Expected Output: 
// 3628800