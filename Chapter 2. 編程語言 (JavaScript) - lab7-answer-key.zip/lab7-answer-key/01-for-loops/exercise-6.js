// Task: Do a summation with the input number
// E.g. if input is 5, calculate 1+2+3+4+5

input = 10

// Add your code here:
let result = 0
for (let i = 0; i<=input; i++){
    result += i
}

console.log(result)

// Expected Output: 
// 55